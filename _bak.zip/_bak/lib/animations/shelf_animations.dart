// lib/animations/shelf_animations.dart
// This file contains more complex animations like the climbing cat

import 'package:flutter/material.dart';
import '../models/animated_object_models.dart';
import '../widgets/gif_player.dart';
import '../widgets/video_player_widget.dart';
import 'package:lottie/lottie.dart';

class ShelfAnimationPlayer extends StatefulWidget {
  final AnimatedObjectInfo animInfo;
  final Size initialSize;
  final Offset initialPosition;
  final AnimationBehavior behavior;
  final VoidCallback onAnimationComplete;

  const ShelfAnimationPlayer({
    Key? key,
    required this.animInfo,
    required this.initialSize,
    required this.initialPosition,
    required this.behavior,
    required this.onAnimationComplete,
  }) : super(key: key);

  @override
  State<ShelfAnimationPlayer> createState() => _ShelfAnimationPlayerState();
}

class _ShelfAnimationPlayerState extends State<ShelfAnimationPlayer>
    with TickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Offset> _positionAnimation;
  late Animation<double> _scaleAnimation;

  // Screen dimensions
  late double _screenWidth;
  late double _screenHeight;

  @override
  void initState() {
    super.initState();

    // Animation controller
    _controller = AnimationController(
      duration: const Duration(seconds: 5),
      vsync: this,
    );

    // Listen for animation completion
    _controller.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        widget.onAnimationComplete();
      }
    });

    // Start animation after build
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _screenWidth = MediaQuery.of(context).size.width;
      _screenHeight = MediaQuery.of(context).size.height;
      _setupAnimations();
      _controller.forward();
    });
  }

  void _setupAnimations() {
    switch (widget.behavior) {
      case AnimationBehavior.inPlace:
        _setupInPlaceAnimation();
        break;

      case AnimationBehavior.expand:
        _setupExpandAnimation();
        break;

      case AnimationBehavior.walkAround:
        _setupWalkAroundAnimation();
        break;

      case AnimationBehavior.climbShelf:
        _setupClimbShelfAnimation();
        break;
    }
  }

  void _setupInPlaceAnimation() {
    // For in-place animation, just pulsate slightly
    _positionAnimation = Tween<Offset>(
      begin: Offset(widget.initialPosition.dx, widget.initialPosition.dy),
      end: Offset(widget.initialPosition.dx, widget.initialPosition.dy),
    ).animate(_controller);

    _scaleAnimation = TweenSequence<double>([
      TweenSequenceItem(tween: Tween<double>(begin: 1.0, end: 1.1), weight: 25),
      TweenSequenceItem(tween: Tween<double>(begin: 1.1, end: 1.0), weight: 25),
      TweenSequenceItem(tween: Tween<double>(begin: 1.0, end: 1.1), weight: 25),
      TweenSequenceItem(tween: Tween<double>(begin: 1.1, end: 1.0), weight: 25),
    ]).animate(_controller);
  }

  void _setupExpandAnimation() {
    // Expand outward and then back
    _positionAnimation = Tween<Offset>(
      begin: Offset(widget.initialPosition.dx, widget.initialPosition.dy),
      end: Offset(widget.initialPosition.dx, widget.initialPosition.dy),
    ).animate(_controller);

    _scaleAnimation = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween<double>(begin: 1.0, end: widget.animInfo.expandRatio),
        weight: 40,
      ),
      TweenSequenceItem(
        tween: Tween<double>(
          begin: widget.animInfo.expandRatio,
          end: widget.animInfo.expandRatio,
        ),
        weight: 20,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: widget.animInfo.expandRatio, end: 1.0),
        weight: 40,
      ),
    ]).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  void _setupWalkAroundAnimation() {
    // Create a path for walking around - example here makes a circle
    final List<Offset> path = [];

    // Starting position
    final double centerX = widget.initialPosition.dx;
    final double centerY = widget.initialPosition.dy;
    const double radius = 100.0;

    // Generate points to form a circle around the initial position
    const int numPoints = 100;
    for (int i = 0; i < numPoints; i++) {
      final double angle = 2 * 3.14159 * i / numPoints;
      path.add(
        Offset(
          centerX + radius * Math.cos(angle),
          centerY + radius * Math.sin(angle),
        ),
      );
    }

    // Path animation
    _positionAnimation = TweenSequence<Offset>(
      List.generate(path.length - 1, (index) {
        return TweenSequenceItem(
          tween: Tween<Offset>(begin: path[index], end: path[index + 1]),
          weight: 1,
        );
      }),
    ).animate(_controller);

    // Scale animation (constant scale)
    _scaleAnimation = Tween<double>(
      begin: widget.animInfo.expandRatio,
      end: widget.animInfo.expandRatio,
    ).animate(_controller);
  }

  void _setupClimbShelfAnimation() {
    // This is a more complex animation for climbing the shelf
    // Define key points in the climbing path

    // Start at the current position
    final double startX = widget.initialPosition.dx;
    final double startY = widget.initialPosition.dy;

    // Climb up to the shelf above (approximately)
    final double midX = startX;
    final double midY = startY - 200; // Move up

    // Then move horizontally to show walking on the shelf
    final double endX = startX + 150; // Move right
    final double endY = midY;

    // Create a sequence of points
    _positionAnimation = TweenSequence<Offset>([
      // First move up (climb)
      TweenSequenceItem(
        tween: Tween<Offset>(
          begin: Offset(startX, startY),
          end: Offset(midX, midY),
        ).chain(CurveTween(curve: Curves.easeOut)),
        weight: 40,
      ),
      // Then walk horizontally on the shelf
      TweenSequenceItem(
        tween: Tween<Offset>(
          begin: Offset(midX, midY),
          end: Offset(endX, endY),
        ).chain(CurveTween(curve: Curves.linear)),
        weight: 30,
      ),
      // Then come back a bit
      TweenSequenceItem(
        tween: Tween<Offset>(
          begin: Offset(endX, endY),
          end: Offset(endX - 50, endY),
        ).chain(CurveTween(curve: Curves.linear)),
        weight: 30,
      ),
    ]).animate(_controller);

    // Scale animation
    _scaleAnimation = Tween<double>(
      begin: widget.animInfo.expandRatio,
      end: widget.animInfo.expandRatio,
    ).animate(_controller);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        // Get current position and scale
        final Offset currentPosition = _positionAnimation.value;
        final double currentScale = _scaleAnimation.value;

        // Calculate size based on scale
        final double width = widget.initialSize.width * currentScale;
        final double height = widget.initialSize.height * currentScale;

        // Position accounting for the center point and scale
        final double left = currentPosition.dx - (width / 2);
        final double top = currentPosition.dy - (height / 2);

        return Positioned(
          left: left,
          top: top,
          width: width,
          height: height,
          child: getAnimatedAssetWidget(),
        );
      },
    );
  }

  Widget getAnimatedAssetWidget() {
    switch (widget.animInfo.animationType) {
      case AnimationType.gif:
        return GifPlayer(
          gifPath: widget.animInfo.animatedAssetPath,
          fit: BoxFit.contain,
          duration: const Duration(milliseconds: 1000),
        );

      case AnimationType.video:
        return AnimatedVideoPlayer(
          videoPath: widget.animInfo.animatedAssetPath,
          autoPlay: true,
          loop: true,
          fit: BoxFit.contain,
        );

      case AnimationType.lottie:
        return Lottie.asset(
          widget.animInfo.animatedAssetPath,
          fit: BoxFit.contain,
          repeat: true,
          animate: true,
        );
    }
  }
}
