// lib/repositories/animated_object_repository.dart

import 'package:flutter/material.dart';
import '../models/animated_object_models.dart';

class AnimatedObjectRepository {
  // Singleton pattern
  static final AnimatedObjectRepository _instance =
      AnimatedObjectRepository._internal();
  factory AnimatedObjectRepository() => _instance;
  AnimatedObjectRepository._internal();

  // Map decoration object IDs to their animation information
  final Map<String, AnimatedObjectInfo> _animatedObjectsMap = {
    'neko': AnimatedObjectInfo(
      objectId: 'neko',
      name: '猫',
      staticImagePath: 'assets/objects/neko.png',
      animatedAssetPath: 'assets/animations/neko_dance.gif',
      animationType: AnimationType.gif,
      behavior: AnimationBehavior.inPlace,
      expandRatio: 1.2,
    ),
    'neko_kin': AnimatedObjectInfo(
      objectId: 'neko_kin',
      name: '金の猫',
      staticImagePath: 'assets/objects/neko_kin.png',
      animatedAssetPath: 'assets/animations/neko_kin_climb.gif',
      animationType: AnimationType.gif,
      behavior: AnimationBehavior.climbShelf,
      expandRatio: 1.5,
    ),
    // Add more animated objects as needed
  };

  // Get animation info for an object if it exists
  AnimatedObjectInfo? getAnimationForObject(String objectId) {
    return _animatedObjectsMap[objectId];
  }

  // Check if an object has animations
  bool hasAnimation(String objectId) {
    return _animatedObjectsMap.containsKey(objectId);
  }
}
