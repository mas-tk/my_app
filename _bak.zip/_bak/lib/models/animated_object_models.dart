// Create a new class to handle animated decoration objects
// lib/models/animated_object_models.dart

import 'package:flutter/material.dart';

class AnimatedObjectInfo {
  final String objectId;
  final String name;
  final String staticImagePath;
  final String animatedAssetPath; // Can be a gif or a video path
  final AnimationType animationType;
  final AnimationBehavior behavior;
  final double expandRatio; // 1.0 means same size, 2.0 means double size, etc.

  AnimatedObjectInfo({
    required this.objectId,
    required this.name,
    required this.staticImagePath,
    required this.animatedAssetPath,
    this.animationType = AnimationType.gif,
    this.behavior = AnimationBehavior.inPlace,
    this.expandRatio = 1.0,
  });
}

enum AnimationType { gif, video, lottie }

enum AnimationBehavior {
  inPlace, // Animation stays in the original boundaries
  expand, // Animation expands beyond boundaries but centered at original position
  walkAround, // Animation can move around on screen
  climbShelf, // Special behavior for climbing the shelves
}
