// lib/widgets/gif_player.dart
import 'package:flutter/material.dart';
import 'package:flutter_gif/flutter_gif.dart';

class GifPlayer extends StatefulWidget {
  final String gifPath;
  final BoxFit fit;
  final double width;
  final double height;
  final bool autoPlay;
  final bool loop;
  final Duration duration;

  const GifPlayer({
    Key? key,
    required this.gifPath,
    this.fit = BoxFit.contain,
    this.width = double.infinity,
    this.height = double.infinity,
    this.autoPlay = true,
    this.loop = true,
    this.duration = const Duration(seconds: 3),
  }) : super(key: key);

  @override
  State<GifPlayer> createState() => _GifPlayerState();
}

class _GifPlayerState extends State<GifPlayer> with TickerProviderStateMixin {
  late FlutterGifController _controller;
  bool _isInitialized = false;

  @override
  void initState() {
    super.initState();
    _controller = FlutterGifController(vsync: this);
    _initializeController();
  }

  Future<void> _initializeController() async {
    await Future.delayed(Duration.zero);
    if (mounted) {
      _controller.repeat(
        min: 0,
        max: _controller.frameCount - 1,
        period: widget.duration,
      );
      setState(() {
        _isInitialized = true;
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_isInitialized) {
      return SizedBox(
        width: widget.width,
        height: widget.height,
        child: const Center(child: CircularProgressIndicator()),
      );
    }

    return GifImage(
      controller: _controller,
      image: AssetImage(widget.gifPath),
      fit: widget.fit,
      width: widget.width,
      height: widget.height,
    );
  }
}
